public class Secretary {

	private String application;
	private String framework;

	public void send_to() {
		// TODO - implement Secretary.send_to
		throw new UnsupportedOperationException();
	}

	public String getApplication() {
		return this.application;
	}

	public String getFramework() {
		return this.framework;
	}

}