public class Members {

	private String application;
	private String framework;
	private String name;

	public void consulatation() {
		// TODO - implement Members.consulatation
		throw new UnsupportedOperationException();
	}

	public String getName() {
		return this.name;
	}

	public String getApplication() {
		return this.application;
	}

	public String getFramework() {
		return this.framework;
	}

	public String setStatus() {
		// TODO - implement Members.setStatus
		throw new UnsupportedOperationException();
	}

}