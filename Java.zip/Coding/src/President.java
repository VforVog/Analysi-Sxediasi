public class President {

	private String application;

	public void check_application() {
		// TODO - implement President.check_application
		throw new UnsupportedOperationException();
	}

	public void registration() {
		// TODO - implement President.registration
		throw new UnsupportedOperationException();
	}

	public Members setMember() {
		// TODO - implement President.setMember
		throw new UnsupportedOperationException();
	}

	public String getApplication() {
		return this.application;
	}

}