public class Professor {

	private String firstName;
	private String lastName;
	private String ID;

	public void create_application() {
		// TODO - implement Professor.create_application
		throw new UnsupportedOperationException();
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getID() {
		return this.ID;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String setStatus() {
		// TODO - implement Professor.setStatus
		throw new UnsupportedOperationException();
	}

}