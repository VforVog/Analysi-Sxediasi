public class Application {

	private String Title;
	private String author;
	private String dateOfApplication;
	private String contents;
	private String scientific_stuff;
	private String bibliography;
	private String id;

	public String getId() {
		return this.id;
	}

	public String getDateofApplication() {
		return this.dateOfApplication;
	}

	public String getContents() {
		return this.contents;
	}

	public String getTitle() {
		return this.Title;
	}

	public String getAuthor() {
		return this.author;
	}

	public String getBibliography() {
		return this.bibliography;
	}

	public String getScientific_stuff() {
		return this.scientific_stuff;
	}

	public String setID() {
		// TODO - implement Application.setID
		throw new UnsupportedOperationException();
	}

	public String setTitle() {
		// TODO - implement Application.setTitle
		throw new UnsupportedOperationException();
	}

}