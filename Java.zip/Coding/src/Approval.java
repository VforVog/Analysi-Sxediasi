public class Approval {

	private String application;
	private String framework;
	private String comments;

	public void make_decision() {
		// TODO - implement Approval.make_decision
		throw new UnsupportedOperationException();
	}

	public void sign_Application() {
		// TODO - implement Approval.sign_Application
		throw new UnsupportedOperationException();
	}

	public void needs_changes() {
		// TODO - implement Approval.needs_changes
		throw new UnsupportedOperationException();
	}

	public String getApplication() {
		return this.application;
	}

	public String getFramework() {
		return this.framework;
	}

	public String getComments() {
		return this.comments;
	}

	public String setDecision() {
		// TODO - implement Approval.setDecision
		throw new UnsupportedOperationException();
	}

}