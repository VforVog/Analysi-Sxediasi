public class Evaluator {

	private String application;

	public void create_framework() {
		// TODO - implement Evaluator.create_framework
		throw new UnsupportedOperationException();
	}

	public String getApplication() {
		return this.application;
	}

}